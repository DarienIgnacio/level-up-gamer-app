package com.example.level_up_gamer_app.data.remote

import com.example.level_up_gamer_app.Model.Producto

fun ProductoDto.toProducto(): Producto {

    // Usamos la primera imagen si existe; si no, el thumbnail
    val imagenFinal = images.firstOrNull() ?: thumbnail

    return Producto(
        id = this.id,
        nombre = this.title,
        descripcion = this.description,
        precio = this.price,        // DummyJSON ya trae Int
        imagen = imagenFinal,
        categoria = this.category,
        stock = this.stock          // Stock real desde la API
    )
}

