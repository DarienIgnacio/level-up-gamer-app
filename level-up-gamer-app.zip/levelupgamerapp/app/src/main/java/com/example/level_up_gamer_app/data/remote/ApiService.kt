package com.example.level_up_gamer_app.data.remote

import retrofit2.http.GET

interface ApiService {

    @GET("products")
    suspend fun getProducts(): ProductsResponse
}

