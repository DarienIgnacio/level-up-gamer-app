package com.example.level_up_gamer_app.repository

import android.content.Context
import com.example.level_up_gamer_app.Model.Producto
import com.example.level_up_gamer_app.data.local.AppDatabase
import com.example.level_up_gamer_app.data.remote.RetrofitClient
import com.example.level_up_gamer_app.data.remote.toProducto

class ProductoRepository {

    // Palabras clave para DETECTAR productos gaming reales
    private val gamingKeywords = listOf(
        "gaming", "gamer", "pc", "computer", "monitor", "mouse", "keyboard",
        "headphone", "headset", "motherboard", "processor", "cpu", "gpu",
        "graphics", "ram", "ssd", "cooler", "fan", "mechanical"
    )

    private val currencyRepo = CurrencyRepository()

    // =====================================================================
    //  API PRINCIPAL → Filtra productos gaming + convierte USD → CLP
    // =====================================================================
    suspend fun obtenerProductosRemotosOCache(context: Context): List<Producto> {
        val db = AppDatabase.getInstance(context)
        val dao = db.productoDao()

        return try {
            // 1. Obtener productos desde API DummyJSON
            val response = RetrofitClient.apiService.getProducts()

            // 2. Filtrar SOLO productos gaming
            val productosGaming = response.products.filter { dto ->
                val t = dto.title.lowercase()
                val d = dto.description.lowercase()
                val c = dto.category.lowercase()

                gamingKeywords.any { key ->
                    key in t || key in d || key in c
                }
            }

            // 3. Convertir DTO → Modelo interno + precio CLP
            val productosConvertidos = productosGaming.map { dto ->
                val producto = dto.toProducto()

                // Convertir USD → CLP usando API ExchangeRate.host
                val precioClp = currencyRepo.usdToClp(producto.precio.toDouble())

                producto.copy(precio = precioClp)
            }

            // 4. Guardar en caché local (Room)
            dao.insertAll(productosConvertidos)

            productosConvertidos

        } catch (e: Exception) {
            e.printStackTrace()

            // Si falla, cargar desde Room
            dao.getAll()
        }
    }

    // Ya no se usa assets, pero lo dejamos para evitar fallos
    fun obtenerProductosDesdeAssets(context: Context, filename: String = "productos.json"): List<Producto> {
        return emptyList()
    }

    // Modo admin: agregar producto manualmente a FakeDatabase
    fun agregarProducto(producto: Producto) {
        com.example.level_up_gamer_app.Model.FakeDatabase.agregarProducto(producto)
    }
}
