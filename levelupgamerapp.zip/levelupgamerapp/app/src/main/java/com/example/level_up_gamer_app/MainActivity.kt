package com.example.level_up_gamer_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.level_up_gamer_app.Viewmodel.AuthViewModel
import com.example.level_up_gamer_app.Viewmodel.CarritoViewModel
import com.example.level_up_gamer_app.viewmodel.CatalogoViewModel
import com.example.level_up_gamer_app.Views.* // Asegúrate de que el paquete es 'views' y no 'Views'

class MainActivity : ComponentActivity() {

    // Se crean las instancias únicas de los ViewModels para toda la app. ¡Esto es correcto!
    private val authViewModel: AuthViewModel by viewModels()
    private val catalogoViewModel: CatalogoViewModel by viewModels()
    private val carritoViewModel: CarritoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val navController = rememberNavController()

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                // El NavHost define todas las rutas de navegación de la app.
                NavHost(
                    navController = navController,
                    startDestination = "login" // La app comienza en la pantalla de login
                ) {

                    // --- Rutas de Autenticación ---

                    composable("login") {
                        LoginScreen(
                            navController = navController,
                            authViewModel = authViewModel // Se pasa la instancia única
                        )
                    }

                    composable("register") {
                        RegisterScreen(
                            navController = navController,
                            authViewModel = authViewModel // Se pasa la misma instancia
                        )
                    }

                    // --- Rutas Principales de la App ---

                    composable("catalogo") {
                        CatalogScreen(
                            navController = navController,
                            catalogoViewModel = catalogoViewModel,
                            carritoViewModel = carritoViewModel
                        )
                    }

                    composable(
                        route = "producto/{id}",
                        arguments = listOf(navArgument("id") { type = NavType.IntType })
                    ) { backStackEntry ->
                        val id = backStackEntry.arguments?.getInt("id") ?: 0
                        ProductDetailScreen(
                            navController = navController,
                            catalogoViewModel = catalogoViewModel,
                            product = id,
                        )
                    }

                    composable("carrito") {
                        CarritoScreen(
                            navController = navController,
                            carritoViewModel = carritoViewModel
                        )
                    }

                    // --- Rutas de Administración ---

                    composable("admin") {
                        AdminScreen(
                            navController = navController,
                            catalogoViewModel = catalogoViewModel
                        )
                    }

                    composable("admin/addProduct") {
                        AddProductScreen(
                            navController = navController,
                            catalogoViewModel = catalogoViewModel
                        )
                    }

                    // --- Rutas de Utilidad ---

                    composable("success") {
                        SuccessScreen(navController)
                    }

                    composable("error") {
                        ErrorScreen(navController)
                    }
                }
            }
        }
    }
}
