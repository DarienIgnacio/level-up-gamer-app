package com.example.level_up_gamer_app.model

data class CarritoItem(
    val producto: Producto,
    val cantidad: Int
)
