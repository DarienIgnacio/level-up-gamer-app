package com.example.level_up_gamer_app.data.remote.dto

data class LoginRequest(
    val email: String,
    val password: String
)