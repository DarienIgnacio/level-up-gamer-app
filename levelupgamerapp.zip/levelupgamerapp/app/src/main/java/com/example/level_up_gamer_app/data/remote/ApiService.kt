package com.example.level_up_gamer_app.data.remote

import retrofit2.Response
import retrofit2.http.*
import com.example.level_up_gamer_app.data.remote.dto.ProductDto
import com.example.level_up_gamer_app.data.remote.dto.LoginRequest
import com.example.level_up_gamer_app.data.remote.dto.LoginResponse
import com.example.level_up_gamer_app.data.remote.dto.RegisterRequest
import com.example.level_up_gamer_app.data.remote.dto.BasicResponse

interface ApiService {

    // Productos
    @GET("api/productos")
    suspend fun getProductos(): List<ProductDto>

    // Auth
    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<BasicResponse>
}
