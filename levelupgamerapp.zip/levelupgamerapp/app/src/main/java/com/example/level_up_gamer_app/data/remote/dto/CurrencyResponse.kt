package com.example.level_up_gamer_app.data.remote.dto

data class CurrencyResponse(
    val rates: Map<String, Double>
)