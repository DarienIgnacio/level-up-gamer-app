package com.example.level_up_gamer_app.repository

import com.example.level_up_gamer_app.data.remote.*
import com.example.level_up_gamer_app.model.Usuario
import com.example.level_up_gamer_app.data.remote.dto.RegisterRequest
import com.example.level_up_gamer_app.data.remote.dto.LoginRequest
import java.lang.Exception



class AuthRepository(
    private val api: ApiService = RetrofitClient.apiService
) {

    suspend fun login(email: String, password: String): Result<Usuario> {
        return try {
            val response = api.login(LoginRequest(email, password))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success) {
                    Result.success(body.toUsuario())
                } else {
                    Result.failure(Exception(body.message))
                }
            } else {
                Result.failure(Exception("Error ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(
        nombre: String,
        email: String,
        rut: String,
        password: String
    ): Result<Unit> {
        return try {
            val response = api.register(
                RegisterRequest(nombre, email, rut, password)
            )
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                if (body.success) Result.success(Unit)
                else Result.failure(Exception(body.message))
            } else {
                Result.failure(Exception("Error ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
