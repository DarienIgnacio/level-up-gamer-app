package com.example.level_up_gamer_app.data.remote

import com.example.level_up_gamer_app.model.Producto
import com.example.level_up_gamer_app.model.Usuario
import com.example.level_up_gamer_app.data.remote.dto.ProductDto
import com.example.level_up_gamer_app.data.remote.dto.LoginResponse

fun ProductDto.toProducto(): Producto =
    Producto(
        id = id,
        nombre = nombre,
        descripcion = descripcion ?: "",
        precio = precio,
        imagen = imagen ?: "",
        categoria = categoria ?: "",
        stock = stock ?: 0
    )

fun LoginResponse.toUsuario(): Usuario =
    Usuario(
        id = 0L,
        nombre = nombre ?: "",
        email = email ?: "",
        rut = rut ?: "",
        esAdmin = esAdmin ?: false,
        token = token
    )
