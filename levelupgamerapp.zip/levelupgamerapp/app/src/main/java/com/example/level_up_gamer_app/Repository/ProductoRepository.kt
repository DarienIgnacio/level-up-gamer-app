package com.example.level_up_gamer_app.repository

import com.example.level_up_gamer_app.data.remote.ApiService
import com.example.level_up_gamer_app.data.remote.dto.ProductDto
import com.example.level_up_gamer_app.model.Producto
import com.example.level_up_gamer_app.data.remote.toProducto
class ProductoRepository(private val api: ApiService) {

    suspend fun obtenerProductos(): List<Producto> {
        return api.getProductos().map { it.toProducto() }
    }

    suspend fun agregarProducto(producto: Producto): Boolean {
        val dto = producto.toDto()
        val response = api.agregarProducto(dto)
        return response.isSuccessful
    }
}
